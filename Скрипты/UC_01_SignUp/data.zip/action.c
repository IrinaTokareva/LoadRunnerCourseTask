Action()
{

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("WebTours", 
		"URL=http://10.0.0.10:1080/WebTours/", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	web_url("header.html", 
		"URL=http://10.0.0.10:1080/WebTours/header.html", 
		"Resource=0", 
		"Referer=http://10.0.0.10:1080/WebTours/", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	web_url("welcome.pl", 
		"URL=http://10.0.0.10:1080/cgi-bin/welcome.pl?signOff=true", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://10.0.0.10:1080/WebTours/", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_url("login.pl", 
		"URL=http://10.0.0.10:1080/cgi-bin/login.pl?username=&password=&getInfo=true", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://10.0.0.10:1080/WebTours/home.html", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Origin", 
		"http://10.0.0.10:1080");

	lr_think_time(11);

	web_submit_form("login.pl_2", 
		"Snapshot=t5.inf", 
		ITEMDATA, 
		"Name=username", "Value=nbvc", ENDITEM, 
		"Name=password", "Value=ggg", ENDITEM, 
		"Name=passwordConfirm", "Value=ggg", ENDITEM, 
		"Name=firstName", "Value=ertsreaa", ENDITEM, 
		"Name=lastName", "Value=drsea", ENDITEM, 
		"Name=address1", "Value=rseasas", ENDITEM, 
		"Name=address2", "Value=asdA", ENDITEM, 
		"Name=register.x", "Value=54", ENDITEM, 
		"Name=register.y", "Value=5", ENDITEM, 
		LAST);

	return 0;
}